// Netlify serverless function - proxies requests to Supabase
// This bypasses the "Host not in allowlist" CORS restriction

const SB_URL = 'https://ekjkiqclyffbzdwuqzni.supabase.co/rest/v1';
const SB_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVramtpcWNseWZmYnpkd3Vxem5pIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzgxMTcxNTksImV4cCI6MjA5MzY5MzE1OX0.KXu3twf7U_IFT_hZA8VAK_Qg7DUc_SySsl9ytqzzmfM';

exports.handler = async (event) => {
  const { httpMethod, queryStringParameters, body } = event;
  
  // Build Supabase URL from query params
  const table = queryStringParameters.table || 'bookings';
  const filter = queryStringParameters.filter || '';
  const order = queryStringParameters.order || '';
  const limit = queryStringParameters.limit || '';
  
  let url = `${SB_URL}/${table}`;
  const params = [];
  if (filter) params.push(filter);
  if (order) params.push(`order=${order}`);
  if (limit) params.push(`limit=${limit}`);
  if (params.length) url += '?' + params.join('&');

  const headers = {
    'apikey': SB_KEY,
    'Authorization': `Bearer ${SB_KEY}`,
    'Content-Type': 'application/json',
  };
  
  if (httpMethod === 'POST') headers['Prefer'] = 'return=representation';
  if (httpMethod === 'PATCH') headers['Prefer'] = 'return=minimal';

  try {
    const response = await fetch(url, {
      method: httpMethod,
      headers,
      body: body || undefined,
    });

    const responseBody = response.status === 204 ? '' : await response.text();
    
    return {
      statusCode: response.status,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Content-Type': 'application/json',
      },
      body: responseBody,
    };
  } catch (err) {
    return {
      statusCode: 500,
      headers: { 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ error: err.message }),
    };
  }
};
